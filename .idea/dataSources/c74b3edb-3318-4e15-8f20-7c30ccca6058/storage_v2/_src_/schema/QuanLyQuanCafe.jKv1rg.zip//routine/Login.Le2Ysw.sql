create
    definer = root@localhost procedure Login(IN user_name varchar(50), IN passwd varchar(8), OUT check_a int)
begin
    set check_a =-1;
    select level into check_a from  Account
    where  user_name=username and passwd = password;
end;

