create
    definer = root@localhost procedure getUser(IN username varchar(50))
begin
    select s.id_Staff, fullname, possition, phone_number, address, birthday, date_start, a.username, password, level
    from Staff s, Account a
    where s.id_Staff = a.idStaff && a.username = username;
end;

