create
    definer = root@localhost procedure get_user(IN user_name varchar(50))
begin
    select id_staff, fullname, possition, birthday, phone_number, address, date_start, username, password, level  from Staff, Account
    where id_staff = idStaff and username = user_name;
end;

