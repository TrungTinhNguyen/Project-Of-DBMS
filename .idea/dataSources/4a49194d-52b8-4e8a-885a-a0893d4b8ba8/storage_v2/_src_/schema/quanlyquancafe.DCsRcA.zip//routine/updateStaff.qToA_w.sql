create
    definer = root@localhost procedure updateStaff(IN ID int, IN name varchar(50), IN pos varchar(50),
                                                   IN addr varchar(50), IN tell int, IN bir date, IN sal float)
begin
    update Staff
        set
            fullname = name,
            possition = pos,
            address = addr,
            phone_number = tell,
            birthday = bir
    where id_staff = ID;
    update Salary
        set
            salary = sal
    where idStaff = ID;
end;

