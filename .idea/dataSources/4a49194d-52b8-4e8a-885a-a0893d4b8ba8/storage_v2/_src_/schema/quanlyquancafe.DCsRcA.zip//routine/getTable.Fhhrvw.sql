create
    definer = root@localhost procedure getTable(IN id int)
begin
    select * from tabledrinks where id = id_table;
end;

