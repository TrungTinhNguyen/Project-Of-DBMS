create
    definer = root@localhost procedure addStaff(IN staffID int, IN full_name varchar(50), IN position varchar(50),
                                                IN addr varchar(50), IN tell int, IN birth date, IN beginDate date,
                                                IN sal float)
begin
    insert into Staff values (staffID, full_name, position, birth, tell, addr, beginDate);
    insert into Salary values (staffID, sal);
end;

