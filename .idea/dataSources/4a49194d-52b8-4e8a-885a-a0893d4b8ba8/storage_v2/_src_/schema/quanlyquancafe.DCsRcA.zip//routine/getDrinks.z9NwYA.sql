create
    definer = root@localhost procedure getDrinks(IN id_bill int)
begin
    select id, idDrinks, amountOf from BillInfo where idBill = id_bill;
end;

