create
    definer = root@localhost procedure createAccount(IN user_name varchar(50), IN id_Staff int, IN passwd varchar(8),
                                                     IN lv tinyint)
begin
	insert into Account (username, idStaff, password, level) values (user_name, id_Staff, passwd, lv);
end;

