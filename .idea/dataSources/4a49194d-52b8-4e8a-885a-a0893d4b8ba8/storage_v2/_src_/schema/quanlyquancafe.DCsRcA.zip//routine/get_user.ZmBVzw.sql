create
    definer = root@localhost procedure get_user(IN user_name varchar(50))
begin
    select id_staff, fullname, possition, phone_number, address, birthday, date_start, username, password, level  from Staff, Account, Salary
    where id_staff = Account.idStaff and id_Staff=Salary.idStaff and username = user_name;
end;

