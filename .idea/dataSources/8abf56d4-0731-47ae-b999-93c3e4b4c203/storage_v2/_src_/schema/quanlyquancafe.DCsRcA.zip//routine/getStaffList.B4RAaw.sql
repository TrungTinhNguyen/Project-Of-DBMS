create
    definer = root@localhost procedure getStaffList()
begin
	select id_staff, fullname, possition, address, phone_number, birthday, date_start, salary from Staff join salary where idStaff=id_staff;
end;

