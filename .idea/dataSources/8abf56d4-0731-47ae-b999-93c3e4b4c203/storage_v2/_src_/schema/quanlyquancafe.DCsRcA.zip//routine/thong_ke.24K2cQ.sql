create
    definer = root@localhost procedure thong_ke(IN user_name varchar(50), IN date_check date)
begin
    select c.id_bill, c.dateCheckIn, a.fullname, e.price from Staff a, Account b, Bill c, BillInfo d, Drinks e
    where  username = user_name and a.id_staff = b.idStaff and c.id_bill=d.idBill and d.idDrinks=e.id_drinks and dateCheckIn = date_check;
end;

