create
    definer = root@localhost procedure delete_staff(IN idstaff int)
begin
	delete from Staff where id_staff= idstaff;
end;

