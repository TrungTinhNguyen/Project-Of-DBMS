create
    definer = root@localhost procedure getStaff(IN id int)
begin
    select id_staff, fullname, possition, address, phone_number, birthday, date_start, salary
    from Staff join salary s on staff.id_staff = s.idStaff
    where id = id_staff;
end;

