create
    definer = root@localhost procedure deleteStaff(IN idstaff int)
begin
	delete from Staff where id_staff= idstaff;
end;

