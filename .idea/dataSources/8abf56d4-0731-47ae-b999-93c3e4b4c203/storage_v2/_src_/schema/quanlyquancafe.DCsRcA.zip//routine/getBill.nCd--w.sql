create
    definer = root@localhost procedure getBill()
begin
    select id_bill, id_table, idStaff, dateCheckIn from Bill;
end;

