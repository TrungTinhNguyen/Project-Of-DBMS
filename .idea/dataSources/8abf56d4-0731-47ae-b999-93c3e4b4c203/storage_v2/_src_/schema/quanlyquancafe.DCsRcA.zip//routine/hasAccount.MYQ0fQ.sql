create
    definer = root@localhost function hasAccount(id_staff int) returns decimal(1)
begin
    declare flag numeric(1);
    set flag = 0;
    select count(*) into flag from Account where idStaff = id_staff;
    return flag;
end;

