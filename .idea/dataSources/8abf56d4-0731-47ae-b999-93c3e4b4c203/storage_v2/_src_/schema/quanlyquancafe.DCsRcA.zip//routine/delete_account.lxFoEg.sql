create
    definer = root@localhost procedure delete_account(IN id int)
begin
	delete from Account where idStaff= id;
end;

