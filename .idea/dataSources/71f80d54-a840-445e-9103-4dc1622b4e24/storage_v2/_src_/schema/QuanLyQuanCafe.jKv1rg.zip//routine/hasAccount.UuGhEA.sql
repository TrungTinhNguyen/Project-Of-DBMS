create
    definer = root@localhost function hasAccount(ID int) returns int
begin
    declare has int;
    set has = 0;
    select count(*) into has
    from Staff, Account A
    where Staff.id_Staff = ID and Staff.id_Staff = A.idStaff;
    return has;
end;

