create
    definer = root@localhost procedure deleteStaff(IN staffID int)
begin
    delete from Salary where idStaff = staffID;
    delete from Account where idStaff = staffID;
    delete from Staff where id_Staff = staffID;
end;

