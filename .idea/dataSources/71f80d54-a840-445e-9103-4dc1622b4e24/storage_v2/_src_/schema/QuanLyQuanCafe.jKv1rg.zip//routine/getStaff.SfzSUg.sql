create
    definer = root@localhost procedure getStaff(IN ID int)
begin
    select id_staff, fullname, possition, address,phone_number , birthday, date_start, salary  from Staff, Salary
    where id_staff = ID and id_Staff=Salary.idStaff;
end;

