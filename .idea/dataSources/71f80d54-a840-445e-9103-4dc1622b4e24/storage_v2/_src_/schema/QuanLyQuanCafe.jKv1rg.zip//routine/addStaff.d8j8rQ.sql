create
    definer = root@localhost procedure addStaff(IN id int, IN name varchar(50), IN pos varchar(50), IN addr varchar(50),
                                                IN tell int, IN bd date, IN begindate date, IN sal float)
begin
    insert into Staff values (id, name, pos, bd,tell, addr, begindate);
    insert into Salary values (id, sal, 0);
end;

