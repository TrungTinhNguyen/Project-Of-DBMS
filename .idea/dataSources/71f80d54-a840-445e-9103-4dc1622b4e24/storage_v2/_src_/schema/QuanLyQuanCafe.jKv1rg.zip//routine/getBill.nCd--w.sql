create
    definer = root@localhost procedure getBill()
begin
    select a.id_bill, a.id_table, a.idStaff, a.dateCheckIn from Bill a;
end;

