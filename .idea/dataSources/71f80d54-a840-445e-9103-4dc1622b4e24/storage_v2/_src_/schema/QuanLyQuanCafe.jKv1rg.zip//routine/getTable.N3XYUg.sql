create
    definer = root@localhost procedure getTable(IN ID int)
begin
    select * from TableDrinks
    where id_table = ID;
end;

