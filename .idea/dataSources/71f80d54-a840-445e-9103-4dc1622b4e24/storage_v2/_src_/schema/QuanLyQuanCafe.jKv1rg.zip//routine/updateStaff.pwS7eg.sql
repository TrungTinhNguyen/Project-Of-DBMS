create
    definer = root@localhost procedure updateStaff(IN ID int, IN name varchar(50), IN pos varchar(50),
                                                   IN addr varchar(50), IN tell int, IN bd date, IN sal float)
begin
    update Staff
    set
        Staff.fullname = name,
        Staff.possition = pos,
        Staff.address = addr,
        Staff.phone_number = tell,
        Staff.birthday = bd
    where id_Staff = ID;
    update Salary
        set
            Salary.salary = sal
    where idStaff = ID;
end;

