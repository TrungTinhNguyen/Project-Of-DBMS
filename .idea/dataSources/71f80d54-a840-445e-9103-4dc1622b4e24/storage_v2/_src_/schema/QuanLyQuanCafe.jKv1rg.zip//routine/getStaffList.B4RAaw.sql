create
    definer = root@localhost procedure getStaffList()
begin
    select a.id_Staff, a.fullname, a.possition,a.address,a.phone_number, a.birthday, a.date_start, b.salary
    from Staff a, Salary b
    where a.id_Staff = b.idStaff;
end;

