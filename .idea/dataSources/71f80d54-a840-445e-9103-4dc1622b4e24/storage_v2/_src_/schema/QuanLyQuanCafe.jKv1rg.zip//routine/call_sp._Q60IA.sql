create
    definer = root@localhost function call_sp() returns int
begin
    call getUser("QLlinh");
    return 1;
end;

