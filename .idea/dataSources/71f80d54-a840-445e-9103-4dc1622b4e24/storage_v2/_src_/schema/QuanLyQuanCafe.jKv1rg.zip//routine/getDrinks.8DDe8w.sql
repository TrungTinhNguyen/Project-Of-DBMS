create
    definer = root@localhost procedure getDrinks(IN bill int)
begin
    select id, idDrinks, amountOf
    from BillInfo
    where idBill = bill;
end;

