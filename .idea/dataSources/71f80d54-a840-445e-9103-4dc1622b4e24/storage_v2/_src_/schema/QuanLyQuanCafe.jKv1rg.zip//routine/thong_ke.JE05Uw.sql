create
    definer = root@localhost procedure thong_ke()
begin
    select c.id_bill, c.dateCheckIn, a.fullname, e.price from Staff a, Account b, Bill c, BillInfo d, Drinks e
    where a.id_staff = b.idStaff and c.id_bill=d.idBill and d.idDrinks=e.id_drinks;
end;

